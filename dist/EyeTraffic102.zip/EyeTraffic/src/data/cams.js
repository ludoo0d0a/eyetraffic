var data_cams = {
    "markers": [
    {
        "lat": 49.4904165983924,
        "lng": 6.11674547195435,
        "html": "<div class=\"contenupopup\"><div title=\"Zoomer et centrer\" class=\"loupe\"><a href=\"javascript: centeretzoom(49.4904165983924,6.11674547195435)\"><img  src=\"/imagesite/loupe.jpg\" border=\"0\"></a></div><img src=\"http://www2.pch.etat.lu/info_trafic/cameras/images/cccam_167.jpg\" height=\"119\" width=\"159\"><br><div class=\"titrepopup2\">Croix de Bettembourg</div><div class=\"localitepopup2\">Dudelange</div></div>",
        "cam": 167,
        "titre": "Croix de Bettembourg",
        "localite": "Dudelange",
        "label": "Camera 167-Croix de Bettembourg,Dudelange"
    },
    {
        "lat": 49.4998798382641,
        "lng": 6.08904361724854,
        "html": "<div class=\"contenupopup\"><div title=\"Zoomer et centrer\" class=\"loupe\"><a href=\"javascript: centeretzoom(49.4998798382641,6.08904361724854)\"><img  src=\"/imagesite/loupe.jpg\" border=\"0\"></a></div><img src=\"http://www2.pch.etat.lu/info_trafic/cameras/images/cccam_164.jpg\" height=\"119\" width=\"159\"><br><div class=\"titrepopup2\">Dudelange</div><div class=\"localitepopup2\">Croix de Bettembourg</div></div>",
        "cam": 164,
        "titre": "Dudelange",
        "localite": "Croix de Bettembourg",
        "label": "Camera 164-Dudelange,Croix de Bettembourg"
    },
    {
        "lat": 49.499329375907,
        "lng": 6.05515122413635,
        "html": "<div class=\"contenupopup\"><div title=\"Zoomer et centrer\" class=\"loupe\"><a href=\"javascript: centeretzoom(49.499329375907,6.05515122413635)\"><img  src=\"/imagesite/loupe.jpg\" border=\"0\"></a></div><img src=\"http://www2.pch.etat.lu/info_trafic/cameras/images/cccam_162.jpg\" height=\"119\" width=\"159\"><br><div class=\"titrepopup2\">Kayl</div><div class=\"localitepopup2\">Dudelange</div></div>",
        "cam": 162,
        "titre": "Kayl",
        "localite": "Dudelange",
        "label": "Camera 162-Kayl,Dudelange"
    },
    {
        "lat": 49.505067119254,
        "lng": 6.04055464267731,
        "html": "<div class=\"contenupopup\"><div title=\"Zoomer et centrer\" class=\"loupe\"><a href=\"javascript: centeretzoom(49.505067119254,6.04055464267731)\"><img  src=\"/imagesite/loupe.jpg\" border=\"0\"></a></div><img src=\"http://www2.pch.etat.lu/info_trafic/cameras/images/cccam_161.jpg\" height=\"119\" width=\"159\"><br><div class=\"titrepopup2\">Kayl</div><div class=\"localitepopup2\">Schifflange</div></div>",
        "cam": 161,
        "titre": "Kayl",
        "localite": "Schifflange",
        "label": "Camera 161-Kayl,Schifflange"
    }
    ]
	/*,"lines": [
     {"colour":"#0000FF", "width":8, 
	 "points":[ 
                {"lat": 49.505067119254, "lng": 6.04055464267731 },
				{"lat": 49.4998798382641, "lng": 6.08904361724854 },
				{"lat": 49.4904165983924, "lng": 6.11674547195435 }
             ]
     }
   ]*/
};